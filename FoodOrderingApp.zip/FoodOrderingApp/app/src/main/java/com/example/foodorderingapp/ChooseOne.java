  package com.example.foodorderingapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

  public class ChooseOne extends AppCompatActivity {

    Button btnchef,btncustomer,btnDeliveryP;
    Intent intent;
    String type;
    ConstraintLayout foodcollageimg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_one);

        AnimationDrawable animationDrawable = new AnimationDrawable();
        animationDrawable.addFrame(getResources().getDrawable(R.drawable.foodcollageimg),3000);
        animationDrawable.addFrame(getResources().getDrawable(R.drawable.img1),3000);
        animationDrawable.addFrame(getResources().getDrawable(R.drawable.img2),3000);
        animationDrawable.addFrame(getResources().getDrawable(R.drawable.img3),3000);
        animationDrawable.addFrame(getResources().getDrawable(R.drawable.img4),3000);
        animationDrawable.addFrame(getResources().getDrawable(R.drawable.img6),3000);
        animationDrawable.addFrame(getResources().getDrawable(R.drawable.img7),3000);
        animationDrawable.addFrame(getResources().getDrawable(R.drawable.img8),3000);
        animationDrawable.addFrame(getResources().getDrawable(R.drawable.img9),3000);
        animationDrawable.addFrame(getResources().getDrawable(R.drawable.img10),3000);

        animationDrawable.setOneShot(false);
        animationDrawable.setEnterFadeDuration(850);
        animationDrawable.setExitFadeDuration(1600);

        foodcollageimg = findViewById(R.id.back3);
        foodcollageimg.setBackgroundDrawable(animationDrawable);
        animationDrawable.start();

        intent = getIntent();
        type = intent.getStringExtra("Home").toString().trim();

        btnchef = (Button)findViewById(R.id.btnchef);
        btncustomer = (Button)findViewById(R.id.btncustomer);
        btnDeliveryP = (Button)findViewById(R.id.btnDeliveryP);

        btnchef.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(type.equals("Email")){
                    Intent loginemail = new Intent(ChooseOne.this,ChefLogin.class);
                    startActivity(loginemail);
                    finish();
                }
                if(type.equals("Phone")){
                    Intent loginphone = new Intent(ChooseOne.this,ChefLoginPhone.class);
                    startActivity(loginphone);
                    finish();
                }
                if(type.equals("SignUp")){
                    Intent Register = new Intent(ChooseOne.this,ChefRegistration.class);
                    startActivity(Register);
                    finish();
                }
            }
        });

        btncustomer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(type.equals("Email")){
                    Intent loginemailcust = new Intent(ChooseOne.this,Login.class);
                    startActivity(loginemailcust);
                    finish();
                }
                if(type.equals("Phone")){
                    Intent loginphonecust = new Intent(ChooseOne.this,LoginPhone.class);
                    startActivity(loginphonecust);
                    finish();
                }
                if(type.equals("SignUp")){
                    Intent Registercust = new Intent(ChooseOne.this,Registration.class);
                    startActivity(Registercust);
                    finish();
                }
            }
        });

        btnDeliveryP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(type.equals("Email")){
                    Intent loginemaildelivery = new Intent(ChooseOne.this,DeliveryLogin.class);
                    startActivity(loginemaildelivery);
                    finish();
                }
                if(type.equals("Phone")){
                    Intent loginphonedelivery = new Intent(ChooseOne.this,DeliveryLoginPhone.class);
                    startActivity(loginphonedelivery);
                    finish();
                }
                if(type.equals("SignUp")){
                    Intent Registerdelivery = new Intent(ChooseOne.this,DeliveryRegistration.class);
                    startActivity(Registerdelivery);
                    finish();
                }
            }
        });



    }
}
package com.example.foodorderingapp;

public class User {
    String Role;

    public User(String role)
    {
        Role=role;
    }
}

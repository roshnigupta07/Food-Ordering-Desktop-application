package com.example.foodorderingapp.SendNotification;

public class MyResponse {

    public int success;
}
package com.example.foodorderingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class MainMenu extends AppCompatActivity {

    Button btnSWE,btnSWP,btnSignUp;
    ImageView foodcollageimg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        final Animation zoomin = AnimationUtils.loadAnimation(this,R.anim.zoomin);
        final Animation zoomout = AnimationUtils.loadAnimation(this,R.anim.zoomout);

        foodcollageimg=findViewById(R.id.back2);
        foodcollageimg.setAnimation(zoomin);
        foodcollageimg.setAnimation(zoomout);

        zoomout.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                foodcollageimg.startAnimation(zoomin);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }

        });

        zoomin.setAnimationListener(new Animation.AnimationListener(){
            @Override
            public void onAnimationStart(Animation animation){

            }

            @Override
            public void onAnimationEnd(Animation animation){
                foodcollageimg.startAnimation(zoomout);
            }

            @Override
            public void onAnimationRepeat(Animation animation){

            }
        });
        btnSWE=(Button)findViewById(R.id.btnSWE);
        btnSWP=(Button)findViewById(R.id.btnSWP);
        btnSignUp=(Button)findViewById(R.id.btnSignUp);

        btnSWE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent btnSWE=new Intent(MainMenu.this,ChooseOne.class);
                btnSWE.putExtra("Home","Email");
                startActivity(btnSWE);
                finish();
            }
        });

        btnSWP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent btnSWP=new Intent(MainMenu.this,ChooseOne.class);
                btnSWP.putExtra("Home","Phone");
                startActivity(btnSWP);
                finish();
            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent btnSignUp=new Intent(MainMenu.this,ChooseOne.class);
                btnSignUp.putExtra("Home","SignUp");
                startActivity(btnSignUp);
                finish();
            }
        });


    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        System.gc();
    }

}